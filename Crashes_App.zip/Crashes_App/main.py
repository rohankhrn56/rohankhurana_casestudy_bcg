from modules.data_analysis import crash_analysis

'''
On submitting the spark-submit command the below condition would pass
'''
if __name__ == '__main__':
    import findspark
    findspark.init()
    from pyspark.sql import SparkSession
    print("*************Starting Application: Crash_Analysis****************")
    spark = SparkSession.builder.appName("Crash_Analysis").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    '''
    The configuration file inside the Config folder is read to identify the data inputs, paths, fileformat etc.
    '''
    print("**********Reading the configuration File************")
    config_df = spark.read.format('csv').option("header", "True").load('Config/config.csv')
    print("************** Starting Analysis****************************")
    
    '''
    Class is created to capture the configuration parameters and individual methods in the class point to each analysis outcome.
    '''
    analyze = crash_analysis(config_df, spark)
    print("**************Analysis 1. Initiating****************************")
    analyze.person_killed_male()
    print("**************Analysis 2. Initiating****************************")
    analyze.two_wheelers_booked()
    print("**************Analysis 3. Initiating****************************")
    analyze.states_with_females()
    print("**************Analysis 4. Initiating****************************")
    analyze.vehicle_with_max_injury()
    print("**************Analysis 5. Initiating****************************")
    analyze.body_type_ethnicity()
    print("**************Closing Application****************************")