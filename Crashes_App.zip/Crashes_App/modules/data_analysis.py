from pyspark.sql.functions import *
from pyspark.sql import window


class crash_analysis():
    def __init__(self, config_df, spark):
        self.sc = spark
        self.charges_filename = config_df.filter(col("Data") == "charges").collect()[0]['Filename']
        self.charges_input_path = config_df.filter(col("Data") == "charges").collect()[0]['Input FilePath']
        self.charges_format = config_df.filter(col("Data") == "charges").collect()[0]['FileFormat']
        self.charges_header = config_df.filter(col("Data") == "charges").collect()[0]['Headers']

        self.damages_filename = config_df.filter(col("Data") == "damages").collect()[0]['Filename']
        self.damages_input_path = config_df.filter(col("Data") == "damages").collect()[0]['Input FilePath']
        self.damages_format = config_df.filter(col("Data") == "damages").collect()[0]['FileFormat']
        self.damages_header = config_df.filter(col("Data") == "damages").collect()[0]['Headers']

        self.endorsement_filename = config_df.filter(col("Data") == "endorsement").collect()[0]['Filename']
        self.endorsement_input_path = config_df.filter(col("Data") == "endorsement").collect()[0]['Input FilePath']
        self.endorsement_format = config_df.filter(col("Data") == "endorsement").collect()[0]['FileFormat']
        self.endorsement_header = config_df.filter(col("Data") == "endorsement").collect()[0]['Headers']

        self.restricts_filename = config_df.filter(col("Data") == "restricts").collect()[0]['Filename']
        self.restricts_input_path = config_df.filter(col("Data") == "restricts").collect()[0]['Input FilePath']
        self.restricts_format = config_df.filter(col("Data") == "restricts").collect()[0]['FileFormat']
        self.restricts_header = config_df.filter(col("Data") == "restricts").collect()[0]['Headers']

        self.primary_person_filename = config_df.filter(col("Data") == "primary_person").collect()[0]['Filename']
        self.primary_person_input_path = config_df.filter(col("Data") == "primary_person").collect()[0]['Input FilePath']
        self.primary_person_format = config_df.filter(col("Data") == "primary_person").collect()[0]['FileFormat']
        self.primary_person_header = config_df.filter(col("Data") == "primary_person").collect()[0]['Headers']

        self.unit_use_filename = config_df.filter(col("Data") == "units_use").collect()[0]['Filename']
        self.unit_use_input_path = config_df.filter(col("Data") == "units_use").collect()[0]['Input FilePath']
        self.unit_use_format = config_df.filter(col("Data") == "units_use").collect()[0]['FileFormat']
        self.unit_use_header = config_df.filter(col("Data") == "units_use").collect()[0]['Headers']

    def person_killed_male(self):
        print("1. Analysis - Find the number of crashes (accidents) in which number of persons killed are male?")
        spark = self.sc
        df = spark.read.format(self.primary_person_format).option("header",self.primary_person_header ).load(self.primary_person_input_path + "/" + self.primary_person_filename)
        male_killed = df.filter(lower(col("PRSN_INJRY_SEV_ID")) == 'killed').filter(lower(col("PRSN_GNDR_ID")) == 'male')
        male_killed.show()
        print("Analysis 1 Result Count: ", str(male_killed.count()))

    def two_wheelers_booked(self):
        print("2. Analysis - How many two wheelers are booked for crashes?")
        spark = self.sc
        df = spark.read.format(self.unit_use_format).option("header",self.unit_use_header ).load(self.unit_use_input_path + "/" + self.unit_use_filename)
        two_wheeler = df.filter(lower(col("VEH_BODY_STYL_ID")).like("%motorcycle%"))
        two_wheeler.show()
        print("Analysis 2 Result Count: ", str(two_wheeler.count()))

    def states_with_females(self):
        print("3. Which state has highest number of accidents in which females are involved?")
        spark = self.sc
        print("Note: Assuming DRVR_LIC_STATE_ID as the state being referred to")
        df = spark.read.format(self.primary_person_format).option("header",self.primary_person_header ).load(self.primary_person_input_path + "/" + self.primary_person_filename)
        states_with_females_crash = df \
                        .filter(lower(col("PRSN_GNDR_ID")) == 'female') \
                        .groupBy("DRVR_LIC_STATE_ID") \
                        .agg(count('*').alias("Crash_Count")).orderBy(col("Crash_Count").desc()).limit(1)
        print("Analysis 3 Sates with maximum female crashed:")
        states_with_females_crash.show()

    def vehicle_with_max_injury(self):
        print("4. Which are the Top 5th to 15th VEH_MAKE_IDs that contribute to a largest number of injuries including death?")
        spark = self.sc
        df = spark.read.format(self.unit_use_format).option("header",self.unit_use_header ).load(self.unit_use_input_path + "/" + self.unit_use_filename)
        df = df.withColumn("Total_Injuries", col("TOT_INJRY_CNT") + col("DEATH_CNT"))
        vehicle_inju = df \
                        .groupBy("VEH_MAKE_ID") \
                        .agg(sum("Total_Injuries").alias("Total_Injuries")).orderBy(col("Total_Injuries").desc()) \
                        .withColumn("ID", row_number().over(window.Window.orderBy(col("Total_Injuries").desc()))) \
                        .filter(col("ID").between(5,15))
        vehicle_inju.show()

    def body_type_ethnicity(self):
        print("5. For all the body styles involved in crashes, mention the top ethnic user group of each unique body style")
        spark = self.sc
        unit_df = spark.read.format(self.unit_use_format).option("header",self.unit_use_header ).load(self.unit_use_input_path + "/" + self.unit_use_filename)
        person_df = spark.read.format(self.primary_person_format).option("header",self.primary_person_header ).load(self.primary_person_input_path + "/" + self.primary_person_filename)
        combined_df = person_df.join(unit_df,['CRASH_ID', 'UNIT_NBR'],'inner')
        combined_df = combined_df.dropDuplicates()
        combined_df = combined_df.groupBy("VEH_BODY_STYL_ID", "PRSN_ETHNICITY_ID").agg(count('*').alias("Counts")).orderBy(col("Counts").desc())
        windowspec = window.Window.partitionBy("VEH_BODY_STYL_ID").orderBy(col("Counts").desc())
        combined_df = combined_df.withColumn("Rank", row_number().over(windowspec)).filter(col("Rank")== 1)
        combined_df.show()